%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ISEL-IPL
%% Instituto Superior Engenharia de Lisboa
%% Instituto Politécnico de Lisboa
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Reccomendations of options to be set/changed in “template.tex”:

  school=isel,
	biblatex={
		…,
		style=numeric, % or any other… depends a lot on the degree!!!
		…,
	},

